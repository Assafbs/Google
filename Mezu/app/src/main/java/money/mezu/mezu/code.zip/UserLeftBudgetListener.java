package money.mezu.mezu;

/**
 * Created by JB on 5/23/17.
 */

public interface UserLeftBudgetListener
{
    void userLeftBudgetCallback(String bid);
}
