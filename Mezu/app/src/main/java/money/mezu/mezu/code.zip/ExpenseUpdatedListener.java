package money.mezu.mezu;

/**
 * Created by JB on 5/10/17.
 */

public interface ExpenseUpdatedListener
{
    void expenseUpdatedCallback();
}
