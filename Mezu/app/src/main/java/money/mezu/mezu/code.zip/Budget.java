package money.mezu.mezu;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by asafb on 4/15/2017.
 */

public class Budget {

    private String mId;
    private ArrayList<Expense> expenses;
    private String name;

    public Budget(String id, String name) {
        super();
        this.mId = id;
        this.name = name;
        expenses = new ArrayList<>();
        //TODO: backend to fill
    }

    public String getId() {
        return mId;
    }
    public void setId(String id) {
        this.mId = id;
    }

    public ArrayList<Expense> getExpenses() {
        return expenses;
    }

    public Expense getExpenseByID(BudgetIdentifier bi){
        for (Expense expense:expenses) {
            if (expense.getId().equals(bi)){
                return expense;
            }
        }
        //ERROR MESSAGE
        return null;
    }

    public HashMap<String, Object> serialize()
    {
        HashMap<String, Object> serialized = new HashMap<String,Object>();
        serialized.put("mId", mId);
        serialized.put("name", name);
        List<HashMap<String, String>> serializedExpenses = new ArrayList<HashMap<String, String>>();
        for (Expense expense : expenses)
        {
            serializedExpenses.add(expense.serialize());
        }
        serialized.put("expenses", serializedExpenses);
        return serialized;
    }

    public String toString(){ return name; }
}
