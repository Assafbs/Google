package money.mezu.mezu;

import java.math.BigInteger;

/**
 * Created by asafb on 4/15/2017.
 */

public class UserIdentifier extends Identifier {
    public UserIdentifier(BigInteger id) {
        super(id);
    }

}
