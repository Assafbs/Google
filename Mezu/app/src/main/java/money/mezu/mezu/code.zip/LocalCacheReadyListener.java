package money.mezu.mezu;

/**
 * Created by JB on 6/10/17.
 */

public interface LocalCacheReadyListener
{
    void localCacheReadyCallback();
}
