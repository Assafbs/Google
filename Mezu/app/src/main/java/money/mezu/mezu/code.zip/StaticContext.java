package money.mezu.mezu;

import android.content.Context;

/**
 * Created by JB on 5/1/17.
 */

public class StaticContext {
    static public Context mContext;
}
